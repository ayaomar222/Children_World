<?php
$conn = mysqli_connect("localhost","root","","children_world" ) 
or die ("error". mysqli_error($conn));
?>